/*
 * PWM.h
 *
 *  Created on: Oct 16, 2021
 *      Author: Mostafa Elsharnoby
 */

#ifndef PWM_SIGNAL_H_
#define PWM_SIGNAL_H_

#include <avr/io.h>

void PWM_Timer0_Init(unsigned char set_duty_cycle);



#endif /* PWM_SIGNAL_H_ */
